select *
from address

INSERT INTO address (address_id, address, district, city_id, postal_code, phone)
VALUES
	(606, '123 Easy Street', 'St. Johns', 433, '123765', '1234567891');

select *
from customer
INSERT INTO customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date)
VALUES
	('603', '2', 'Mary', 'Jones', 'mary.jones@email.com', 606, TRUE, CURRENT_DATE),
	('604', '2','John', 'Jones', 'john.jones@email.com', 606, TRUE, CURRENT_DATE),
	('605', '2', 'Jack', 'Jones', 'jack.jones@email.com', 606, TRUE, CURRENT_DATE),
	('606', '2', 'Beth', 'Jones', 'beth.jones@email.com', 606, TRUE, CURRENT_DATE);
	
UPDATE customer
SET active = 1
WHERE customer_id > 602

UPDATE address
SET address = '321 Newfoundland Lane',
	district = 'Carbonear',
	postal_code = 332112
WHERE address_id = 606;
	