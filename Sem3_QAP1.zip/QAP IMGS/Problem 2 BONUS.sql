SELECT store.manager_staff_id, customer.store_id, COUNT(*) AS num_customers
FROM customer
JOIN store ON customer.store_id = store.store_id
GROUP BY customer.store_id, store.manager_staff_id
ORDER BY num_customers ASC;




